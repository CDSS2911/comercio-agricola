"""Permisos centralizados."""

